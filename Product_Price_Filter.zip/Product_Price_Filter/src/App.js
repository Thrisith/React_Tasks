import './App.css';
import {Button , Card} from 'react-bootstrap';
import React from 'react';

const itemData = [
  {id: 100, imageUrl: "./productImage/iphone.png", title: "Apple", price: 500, subtitle: "Lorem Ipsum is simply dummy text of the printing and typesetting industry."},
  {id: 101, imageUrl: "./productImage/samsung.jpg", title: "Samsung", price: 450, subtitle: "Lorem Ipsum is simply dummy text of the printing and typesetting industry."},
  {id: 102, imageUrl: "./productImage/oneplus.jpg", title: "Oneplus", price: 300, subtitle: "Lorem Ipsum is simply dummy text of the printing and typesetting industry."},
  {id: 100, imageUrl: "./productImage/iphone.png", title: "Apple", price: 250, subtitle: "Lorem Ipsum is simply dummy text of the printing and typesetting industry."},
  {id: 101, imageUrl: "./productImage/samsung.jpg", title: "Samsung", price: 499, subtitle: "Lorem Ipsum is simply dummy text of the printing and typesetting industry."},
  {id: 102, imageUrl: "./productImage/oneplus.jpg", title: "Oneplus", price: 199, subtitle: "Lorem Ipsum is simply dummy text of the printing and typesetting industry."}
];


class App extends React.Component {
  state = {
      minvalue:"",
      maxvalue:""
    };

  minchange = (e) => {
    this.setState({
      minvalue: e.target.value
    });
  }
  maxchange = (e) => {
    this.setState({
      maxvalue: e.target.value
    });
  }

  render()
  {
  return (
    <div>
  <div className="filter">
    <input type="text" className="min" placeholder="Minvalue (100)" onChange={this.minchange}/>&nbsp;
   <input type="text" className="max" placeholder="Maxvalue (600)" onChange={this.maxchange}/>
   </div>
   <br/>
   {itemData.filter( itemData=> (itemData.price > this.state.minvalue)&&(itemData.price < this.state.maxvalue)).map(item => (
      <div className="products">
      <div className="Mobiles" key={item.id}>
          <Card>
              <Card.Img className="image" src={item.imageUrl} alt="product" />
              <Card.Body>
                  <Card.Title className="title">{item.title}</Card.Title>
                  <Card.Subtitle className="price">${item.price}</Card.Subtitle>
                  <Card.Text className="sub-title">{item.subtitle}</Card.Text>
                  <Button variant="primary" className="button">Add To Cart</Button>
              </Card.Body>
          </Card>
      </div>
      </div>
  ))}
  </div>
  );
}
}

export default App;
