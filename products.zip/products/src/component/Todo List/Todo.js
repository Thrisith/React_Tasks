import React from 'react';
class Todo extends React.Component
{
  render()
  {
    return(
        <div>
            <input type="text"/>
            <button>Add</button>
            <div>
                <ul>
                    <li>

                    </li>
                </ul>
            </div>
        </div>
    );
  }
  }
  export default Products;