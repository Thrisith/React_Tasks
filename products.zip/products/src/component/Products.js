import React from 'react';
import iphone from './iphone.png'
import samsung from './samsung.jpg'
import oneplus from './oneplus.jpg'
class Products extends React.Component
{
  constructor(props)
  {
    super(props);
    this.state= {name:"Samsung"};
  }

  render()
  {
    return(
      <div className="products">
        <div className="container">
          <div className="image1"><img src={iphone} alt="iphone 12"/></div>
          <div className="name">{this.props.name}</div>          
          <div className="price">{this.props.price}</div>
          <button>{this.props.add}</button>
        </div>
        <div className="container">
          <div className="image2"><img src={samsung} alt="iphone 12"/></div>
          <div className="name">{this.state.name}</div>          
          <div className="price">$900</div>
          <button>{this.props.add}</button>
        </div>
        <div className="container">
          <div className="image3"><img src={oneplus} alt="iphone 12"/></div>
          <div className="name">Oneplus</div>          
          <div className="price">$800</div>
          <button>{this.props.add}</button>
        </div>
      </div>
    );
  }
  }
  export default Products;