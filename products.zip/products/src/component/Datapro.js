import React from 'react'
function Datapro(props)
{
    return(
        <div>Hello {props.name} {props.company} </div>
    )
}
export default Datapro;